include .SCRAM/slc6_amd64_gcc481/MakeData/Tools/SCRAMBased/coral.mk
