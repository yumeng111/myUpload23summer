ALL_TOOLS      += clhep
clhep_EX_INCLUDE := /cvmfs/cms.cern.ch/slc6_amd64_gcc481/external/clhep/2.1.4.1/include
clhep_EX_LIB := CLHEP

