ALL_TOOLS      += evtgenlhc
evtgenlhc_EX_INCLUDE := /cvmfs/cms.cern.ch/slc6_amd64_gcc481/external/evtgenlhc/9.1-cms2
evtgenlhc_EX_LIB := evtgenlhc
evtgenlhc_EX_USE := clhep

