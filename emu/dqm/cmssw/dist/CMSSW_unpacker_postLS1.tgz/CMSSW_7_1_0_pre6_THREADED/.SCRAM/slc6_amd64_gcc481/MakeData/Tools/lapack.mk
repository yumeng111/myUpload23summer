ALL_TOOLS      += lapack

