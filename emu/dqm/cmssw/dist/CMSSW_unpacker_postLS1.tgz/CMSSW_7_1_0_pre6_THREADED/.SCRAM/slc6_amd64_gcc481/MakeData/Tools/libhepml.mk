ALL_TOOLS      += libhepml
libhepml_EX_INCLUDE := /cvmfs/cms.cern.ch/slc6_amd64_gcc481/external/libhepml/0.2.1/interface
libhepml_EX_LIB := hepml

